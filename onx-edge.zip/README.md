# onx-edge — Booking Management System

A full-featured booking platform built with **Laravel 12**, supporting three booking types: Events, Appointments, and Subscriptions. Includes a client portal, admin dashboard, worker management, and payment tracking.

---

## Tech Stack

| Layer | Technology |
|---|---|
| Backend | Laravel 12, PHP 8.2+ |
| Frontend | Livewire 3, Alpine.js, TailwindCSS, Vite |
| Auth | Laravel Passport (API), Guards (admin/client/worker) |
| Media | Spatie MediaLibrary 11 |
| PDF | DomPDF 3 |
| Tables | Yajra DataTables 12 |
| Calendar | FullCalendar |
| Debug | Laravel Telescope |
| Static Analysis | PHPStan (Larastan) level 5 |

---

## Requirements

- PHP 8.2+
- Composer 2.x
- Node.js 18+ and npm
- MySQL 8+ (or SQLite for development)

---

## Local Setup

```bash
# 1. Clone and install dependencies
git clone <repo-url> onx-edge
cd onx-edge
composer install
npm install

# 2. Configure environment
cp .env.example .env
php artisan key:generate

# 3. Edit .env — set DB_DATABASE, DB_USERNAME, DB_PASSWORD, MAIL_*, etc.

# 4. Run migrations and seed
php artisan migrate:fresh --seed

# 5. Install Passport keys
php artisan passport:install

# 6. Link storage
php artisan storage:link

# 7. Build frontend assets
npm run dev        # development (with HMR)
npm run build      # production
```

### Telescope (dev only)

Telescope is enabled in the `local` environment only. Access it at `/telescope`.

---

## Running Tests

```bash
# All tests
php artisan test

# Specific suite
php artisan test --testsuite=Unit
php artisan test --testsuite=Feature

# With coverage report (requires Xdebug or PCOV)
php artisan test --coverage
```

Tests use an in-memory SQLite database — no separate test DB needed.

---

## Static Analysis

```bash
./vendor/bin/phpstan analyse
```

Level 5 is enforced. Fix all errors before opening a PR.

---

## Project Structure

```
app/
├── DTOs/               # PricingResult and other value objects
├── Enums/              # BookingStatus, BookingType, TimeMode, CategoryType
├── Http/
│   └── Controllers/
│       ├── Admin/      # Admin panel controllers
│       ├── Client/     # Client portal controllers
│       ├── Worker/     # Worker-facing controllers
│       └── Front/      # Public-facing controllers
├── Livewire/
│   └── Booking/        # EventBookingWizard, AppointmentBookingWizard, SubscriptionBookingWizard
├── Models/
│   ├── Booking/        # Booking, EventBooking, AppointmentBooking, SubscriptionBooking, BookingItem, …
│   ├── Client/         # Client, ClientMessage, …
│   ├── Event/          # Venue, Wilaya, TravelZone
│   ├── Service/        # Service, Package, PackageOption, Category
│   └── Subscription/   # Subscription
└── Services/
    ├── BookingService.php        # Core booking creation (all three types)
    ├── PricingCalculator.php     # Price computation per booking type
    ├── AvailabilityService.php   # Date/slot availability checks
    ├── TimeCostCalculator.php    # Extra time charges (standard + wedding modes)
    ├── TravelCostCalculator.php  # Travel zone / venue travel cost
    └── PromoCodeService.php      # Promo code validation and application
```

---

## Booking Types

### Event
Full-day or multi-hour events (e.g., weddings, corporate shoots). Supports:
- Package selection or custom package builder
- Venue/wilaya selection with travel cost
- Time-based extra charges (standard or wedding mode)
- Promo codes

### Appointment
Time-slot bookings with overlap detection. Supports:
- Package selection
- Slot availability checks

### Subscription
Monthly recurring plans. Supports:
- Manual or automatic renewal
- Package-based pricing

---

## Authentication

Three separate guards:

| Guard | Login URL | Description |
|---|---|---|
| `web` (admin) | `/login` | Admin users with roles & permissions |
| `client` | `/client/login` | Customers — auto-created on first booking |
| `worker` | `/worker/login` | Field workers assigned to bookings |

Clients are auto-created on booking. A random password is generated and shown once on the confirmation page.

---

## Key Design Decisions

See [`ARCHITECTURE.md`](./ARCHITECTURE.md) for full reasoning. Summary:

- **Separate sub-type tables** (`event_bookings`, `appointment_bookings`, `subscription_bookings`) instead of nullable columns on `bookings` — keeps the schema clean and queries fast.
- **PricingResult DTO** passed between layers instead of raw arrays — type-safe, predictable.
- **DB::transaction** wraps every booking creation — no partial records possible.
- **Squashed migration** — single file replaces 131 migrations for fast `migrate:fresh`.

---

## Environment Variables (important ones)

```env
APP_NAME=onx-edge
APP_URL=http://localhost

DB_CONNECTION=mysql
DB_HOST=127.0.0.1
DB_PORT=3306
DB_DATABASE=onx_edge
DB_USERNAME=root
DB_PASSWORD=

MAIL_MAILER=smtp
MAIL_HOST=
MAIL_PORT=587
MAIL_USERNAME=
MAIL_PASSWORD=

TELESCOPE_ENABLED=true   # set to false in production
```

---

## Contributing

1. Branch from `main`: `git checkout -b feature/your-feature`
2. Write tests for new logic
3. Run `php artisan test` and `./vendor/bin/phpstan analyse` — both must pass
4. Open a pull request with a clear description
