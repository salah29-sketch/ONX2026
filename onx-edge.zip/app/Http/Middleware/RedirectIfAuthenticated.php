<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Symfony\Component\HttpFoundation\Response;

class RedirectIfAuthenticated
{
    public function handle(Request $request, Closure $next, string ...$guards): Response
    {
        $guards = empty($guards) ? [null] : $guards;

        foreach ($guards as $guard) {
            if (Auth::guard($guard)->check()) {
                if ($guard === 'client') {
                    return redirect()->route('client.dashboard');
                }
                if ($guard === 'worker') {
                    return redirect()->route('worker.dashboard');
                }
                if ($guard === 'web') {
                    return redirect()->route('admin.home');
                }
                return redirect('/');
            }
        }

        return $next($request);
    }
}
