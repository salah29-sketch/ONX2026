<?php return array (
  'booking.appointment-booking-wizard' => 'App\\Http\\Livewire\\Booking\\AppointmentBookingWizard',
  'booking.booking-page' => 'App\\Http\\Livewire\\Booking\\BookingPage',
  'booking.event-booking-wizard' => 'App\\Http\\Livewire\\Booking\\EventBookingWizard',
  'booking.subscription-booking-wizard' => 'App\\Http\\Livewire\\Booking\\SubscriptionBookingWizard',
);